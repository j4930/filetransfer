from django.shortcuts import render
import os , mimetypes ,time
import urllib.parse
from django.http import HttpResponse,HttpResponseRedirect
from ipware.ip import get_ip
from .models import getUser
from .forms import UploadFile
from django.conf import settings

# Create your views here.

c = getUser.objects.all()
def Form(request):
    return render(request, 'file/form.html',{'c':c})

def Submit(request):
    if c.count == 1:
        if c.userIp != get_ip(request):
            #버튼이 눌렸고 받기버튼과 보내기버튼을 다른사용자가 눌렀을 경우.
            Upload(request)
            return render(request, 'file/finish.html')
    else:
        return render(request, 'file/nonetarget.html')

def Get(request):
    c.userIp = get_ip(request) #받기 버튼을 누른 사용자를 구분하기위함.
    c.count =1 #받기버튼을 눌렀는지를 구분.

    # 상대방이 보내기를 누를 때까지 폴링하는 방식으로 요청
    while os.listdir(settings.MEDIA_ROOT) == []:
        time.sleep(1)
        return HttpResponseRedirect('/get')
    return HttpResponseRedirect('/download')

def Upload(request):
    if request.method == "POST":
        form = UploadFile(request.POST, request.FILES)
        if form.is_valid():
            if request.FILES['file'].size<4*(2**30): #보낸 파일이 4GB보다 큰지 확인.
                handle_uploaded_file(request.FILES['file'])
                return HttpResponse('전송끝')
            else:
                return HttpResponse("파일크기가 4GB를 초과합니다.")
        else:
            form = UploadFile()
    context = {'form': form}
    return render(request,'file/form.html', context)

def handle_uploaded_file(file,path=''):
    filename = file._get_name()
    destination_file = open('%s/%s' % (settings.MEDIA_ROOT, str(path) + str(filename)), 'wb+')

    for chunk in file.chunks():
        destination_file.write(chunk)
    destination_file.close()

def download(request):
    filelist = os.listdir(settings.MEDIA_ROOT)
    for fp in filelist:
        filepath = os.path.join(settings.MEDIA_ROOT,fp) #임시폴더에 들어있는 파일
        filename = fp
    #임시폴더에 있는 파일 타입과 이름 사이즈읽기 및 다운로드
    downloadfile = open(filepath,'rb')
    response = HttpResponse(downloadfile.read())
    downloadfile.close()
    type, encoding = mimetypes.guess_type(filename)
    if type is None:
        type = 'application/octet-stream'
    response['Content-Type'] = type
    response['Content-Length'] = str(os.stat(filepath).st_size)

    if encoding is not None:
        response['Content-Encoding'] = encoding
    if u'WebKit' in request.META['HTTP_USER_AGENT']:
        filename_header = 'filename=%s' % filename.encode('utf-8')
    elif u'MSIE' in request.META['HTTP_USER_AGENT']:
        filename_header = ''
    else:
        filename_header = 'filename*=UTF-8\'\'%s' % urllib.parse.quote(filename.encode('utf-8'))
    response['Content-Disposition'] = 'attachment; ' + filename_header
    os.remove(filepath) #파일다운로드 시작시 임시폴더에서 파일삭제
    return response





