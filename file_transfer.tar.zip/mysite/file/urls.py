from django.conf.urls import *
from file import views

urlpatterns = [
    url(r'^$',views.Form),
    url(r'^get/$',views.Get),
    url(r'^submit/$',views.Submit),
    #url(r'^upload/$', views.Upload),
    url(r'^download/$', views.download),

]
