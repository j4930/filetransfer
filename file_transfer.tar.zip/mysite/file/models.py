from django.db import models
class getUser(models.Model):
    userIp = models.CharField(max_length=18,default='0.0.0.0')
    count = models.IntegerField(default = 0)
# Create your models here.
